<?php
require_once 'config.php';

$success_message = '';
$error_message = '';

// Обработка формы добавления записи
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_record') {
    try {
        $employee_surname = trim($_POST['employee_surname'] ?? '');
        $sug_end_amount = round((float)($_POST['sug_end_amount'] ?? 0), 2);
        $report_month = (int)($_POST['report_month'] ?? date('n'));
        $report_year = (int)($_POST['report_year'] ?? date('Y'));

        if (empty($employee_surname)) {
            throw new Exception('Необходимо указать фамилию сотрудника');
        }

        if ($sug_end_amount <= 0) {
            throw new Exception('СУГ на конец смены должен быть больше 0');
        }

        // Получаем предыдущую запись для этого сотрудника
        $prev_sql = "SELECT sug_end_amount FROM monthly_reports
                     WHERE employee_surname = :surname
                     AND ((report_year = :year AND report_month < :month) OR report_year < :year)
                     ORDER BY report_year DESC, report_month DESC
                     LIMIT 1";

        $prev_stmt = $pdo->prepare($prev_sql);
        $prev_stmt->execute([
            'surname' => $employee_surname,
            'year' => $report_year,
            'month' => $report_month
        ]);

        $previous_record = $prev_stmt->fetch();
        $previous_sug_amount = $previous_record ? $previous_record['sug_end_amount'] : 0;

        // Один сотрудник может иметь несколько записей в месяце

        // Вставляем новую запись
        $insert_sql = "INSERT INTO monthly_reports
                       (employee_surname, sug_end_amount, previous_sug_amount, report_month, report_year)
                       VALUES (:surname, :sug_end, :previous_sug, :month, :year)";

        $insert_stmt = $pdo->prepare($insert_sql);
        $insert_stmt->execute([
            'surname' => $employee_surname,
            'sug_end' => $sug_end_amount,
            'previous_sug' => $previous_sug_amount,
            'month' => $report_month,
            'year' => $report_year
        ]);

        $success_message = "Запись успешно добавлена! Разница с предыдущим СУГ: " .
                          formatNumber($sug_end_amount - $previous_sug_amount) . " руб.";

    } catch (Exception $e) {
        $error_message = "Ошибка: " . $e->getMessage();
    }
}

// Обработка расчета данных
$calculated_data = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'calculate') {
    $selected_month = (int)($_POST['calc_month'] ?? date('n'));
    $selected_year = (int)($_POST['calc_year'] ?? date('Y'));

    // Получаем все записи за выбранный месяц
    $calc_sql = "SELECT
                    employee_surname,
                    sug_end_amount,
                    previous_sug_amount,
                    total_difference,
                    created_at
                 FROM monthly_reports
                 WHERE report_month = :month AND report_year = :year
                 ORDER BY employee_surname ASC";

    $calc_stmt = $pdo->prepare($calc_sql);
    $calc_stmt->execute(['month' => $selected_month, 'year' => $selected_year]);
    $calculated_data = $calc_stmt->fetchAll();
}

// Получаем последние записи для отображения
$recent_sql = "SELECT * FROM monthly_reports_view ORDER BY created_at DESC LIMIT 10";
$recent_stmt = $pdo->query($recent_sql);
$recent_records = $recent_stmt->fetchAll();

// Массив месяцев на русском
$months = [
    1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 4 => 'Апрель',
    5 => 'Май', 6 => 'Июнь', 7 => 'Июль', 8 => 'Август',
    9 => 'Сентябрь', 10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
];
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Продано за месяц - АГЗС</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Система учета АГЗС</h1>
            <nav>
                <a href="index.php" class="tab-btn">Закрытие смены</a>
                <a href="reports.php" class="tab-btn">Отчеты</a>
                <a href="monthly.php" class="tab-btn active">Продано за месяц</a>
            </nav>
        </header>

        <?php if ($success_message): ?>
            <div class="alert alert-success"><?= escape($success_message) ?></div>
        <?php endif; ?>

        <?php if ($error_message): ?>
            <div class="alert alert-error"><?= escape($error_message) ?></div>
        <?php endif; ?>

        <main>
            <div class="monthly-reports">
                <!-- Форма добавления записи -->
                <section class="add-record-section">
                    <h2>Добавить запись</h2>
                    <form method="POST" action="" class="monthly-form">
                        <input type="hidden" name="action" value="add_record">

                        <div class="form-row">
                            <div class="field-item">
                                <label for="employee_surname">Фамилия:</label>
                                <input type="text"
                                       id="employee_surname"
                                       name="employee_surname"
                                       required
                                       placeholder="Введите фамилию сотрудника"
                                       value="<?= escape($_POST['employee_surname'] ?? '') ?>">
                            </div>

                            <div class="field-item">
                                <label for="sug_end_amount">СУГ на конец смены:</label>
                                <input type="number"
                                       id="sug_end_amount"
                                       name="sug_end_amount"
                                       step="0.01"
                                       min="0"
                                       required
                                       placeholder="0.00"
                                       value="<?= escape($_POST['sug_end_amount'] ?? '') ?>">
                                <small>Введите с точностью до копеек</small>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="field-item">
                                <label for="report_month">Месяц:</label>
                                <select id="report_month" name="report_month" required>
                                    <?php
                                    $current_month = $_POST['report_month'] ?? date('n');
                                    foreach ($months as $num => $name): ?>
                                        <option value="<?= $num ?>" <?= $num == $current_month ? 'selected' : '' ?>>
                                            <?= $name ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field-item">
                                <label for="report_year">Год:</label>
                                <input type="number"
                                       id="report_year"
                                       name="report_year"
                                       min="2020"
                                       max="2030"
                                       required
                                       value="<?= $_POST['report_year'] ?? date('Y') ?>">
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary">Добавить запись</button>
                        </div>
                    </form>
                </section>

                <!-- Форма расчета -->
                <section class="calculate-section">
                    <h2>Рассчитать за месяц</h2>
                    <form method="POST" action="" class="calculate-form">
                        <input type="hidden" name="action" value="calculate">

                        <div class="form-row">
                            <div class="field-item">
                                <label for="calc_month">Месяц для расчета:</label>
                                <select id="calc_month" name="calc_month" required>
                                    <?php
                                    $selected_calc_month = $_POST['calc_month'] ?? date('n');
                                    foreach ($months as $num => $name): ?>
                                        <option value="<?= $num ?>" <?= $num == $selected_calc_month ? 'selected' : '' ?>>
                                            <?= $name ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="field-item">
                                <label for="calc_year">Год для расчета:</label>
                                <input type="number"
                                       id="calc_year"
                                       name="calc_year"
                                       min="2020"
                                       max="2030"
                                       required
                                       value="<?= $_POST['calc_year'] ?? date('Y') ?>">
                            </div>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-success">Рассчитать</button>
                        </div>
                    </form>
                </section>

                <!-- Результаты расчета -->
                <?php if (!empty($calculated_data)): ?>
                <section class="calculation-results">
                    <h2>Результаты расчета за <?= $months[$selected_month] ?> <?= $selected_year ?> г.</h2>
                    <div class="table-container">
                        <table class="results-table">
                            <thead>
                                <tr>
                                    <th>Фамилия</th>
                                    <th>СУГ на конец смены</th>
                                    <th>Сумма</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $total_sum = 0;
                                foreach ($calculated_data as $row):
                                    $sum = $row['sug_end_amount'] + $row['previous_sug_amount'];
                                    $total_sum += $sum;
                                ?>
                                    <tr>
                                        <td><?= escape($row['employee_surname']) ?></td>
                                        <td><?= formatNumber($row['sug_end_amount']) ?> руб.</td>
                                        <td class="total-cell"><?= formatNumber($sum) ?> руб.</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr class="total-row">
                                    <td colspan="2"><strong>Итого:</strong></td>
                                    <td class="total-cell"><strong><?= formatNumber($total_sum) ?> руб.</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </section>
                <?php endif; ?>

                <!-- Последние записи -->
                <?php if (!empty($recent_records)): ?>
                <section class="recent-records">
                    <h2>Последние записи</h2>
                    <div class="table-container">
                        <table class="recent-table">
                            <thead>
                                <tr>
                                    <th>Фамилия</th>
                                    <th>СУГ на конец</th>
                                    <th>Предыдущий СУГ</th>
                                    <th>Разница</th>
                                    <th>Месяц/Год</th>
                                    <th>Создано</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_records as $record): ?>
                                    <tr>
                                        <td><?= escape($record['employee_surname']) ?></td>
                                        <td><?= formatNumber($record['sug_end_amount']) ?> руб.</td>
                                        <td><?= formatNumber($record['previous_sug_amount']) ?> руб.</td>
                                        <td class="<?= $record['total_difference'] >= 0 ? 'positive' : 'negative' ?>">
                                            <?= formatNumber($record['total_difference']) ?> руб.
                                        </td>
                                        <td><?= $months[$record['report_month']] ?> <?= $record['report_year'] ?></td>
                                        <td><?= $record['formatted_created_at'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script src="src/script.js"></script>
</body>
</html>
