<?php
require_once 'config.php';

$shift_id = (int)($_GET['id'] ?? 0);

if (!$shift_id) {
    header('Location: reports.php?error=invalid_id');
    exit;
}

// Проверяем, существует ли запись
$check_sql = "SELECT id, shift_date, shift_time FROM shift_closures WHERE id = :id";
$check_stmt = $pdo->prepare($check_sql);
$check_stmt->execute(['id' => $shift_id]);
$shift = $check_stmt->fetch();

if (!$shift) {
    header('Location: reports.php?error=shift_not_found');
    exit;
}

$error_message = '';
$success_message = '';

// Обработка подтверждения удаления
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    try {
        $delete_sql = "DELETE FROM shift_closures WHERE id = :id";
        $delete_stmt = $pdo->prepare($delete_sql);
        $delete_stmt->execute(['id' => $shift_id]);

        if ($delete_stmt->rowCount() > 0) {
            header('Location: reports.php?success=shift_deleted');
            exit;
        } else {
            $error_message = 'Не удалось удалить запись';
        }
    } catch (Exception $e) {
        $error_message = 'Ошибка при удалении: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Удаление смены №<?= $shift['id'] ?> - АГЗС</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Система учета АГЗС</h1>
            <nav>
                <a href="index.php" class="tab-btn">Закрытие смены</a>
                <a href="reports.php" class="tab-btn">Отчеты</a>
                <a href="monthly.php" class="tab-btn">Продано за месяц</a>
            </nav>
        </header>

        <main>
            <div class="delete-confirmation">
                <h2>Подтверждение удаления</h2>

                <?php if ($error_message): ?>
                    <div class="alert alert-error"><?= escape($error_message) ?></div>
                <?php endif; ?>

                <div class="warning-box">
                    <div class="warning-icon">⚠️</div>
                    <div class="warning-content">
                        <h3>Внимание!</h3>
                        <p>Вы собираетесь удалить смену №<?= $shift['id'] ?> от <?= date('d.m.Y', strtotime($shift['shift_date'])) ?> <?= date('H:i', strtotime($shift['shift_time'])) ?>.</p>
                        <p><strong>Это действие необратимо!</strong> Все данные о смене будут безвозвратно утеряны.</p>
                    </div>
                </div>

                <div class="confirmation-actions">
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="confirm_delete" value="1">
                        <button type="submit" class="btn btn-danger btn-large" onclick="return confirm('Вы точно уверены? Данные будут удалены безвозвратно!')">
                            Да, удалить смену
                        </button>
                    </form>

                    <a href="reports.php" class="btn btn-secondary btn-large">
                        Отмена
                    </a>

                    <a href="view_shift.php?id=<?= $shift['id'] ?>" class="btn btn-info btn-large">
                        Просмотреть смену
                    </a>
                </div>

                <div class="deletion-info">
                    <h4>Что будет удалено:</h4>
                    <ul>
                        <li>Все данные о закрытии смены</li>
                        <li>Информация о подсчете наличных денег</li>
                        <li>Показатели СУГ и процентовщика</li>
                        <li>Расчеты и отклонения</li>
                        <li>История создания и изменения записи</li>
                    </ul>
                </div>
            </div>
        </main>
    </div>

    <script src="src/script.js"></script>
</body>
</html>
