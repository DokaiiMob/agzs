<?php
require_once 'config.php';

$shift_id = (int)($_GET['id'] ?? 0);

if (!$shift_id) {
    header('Location: reports.php');
    exit;
}

// Получение данных смены
$sql = "SELECT * FROM shift_closures WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $shift_id]);
$shift = $stmt->fetch();

if (!$shift) {
    header('Location: reports.php?error=shift_not_found');
    exit;
}

// Форматирование данных
$shift['formatted_date'] = date('d.m.Y', strtotime($shift['shift_date']));
$shift['formatted_time'] = date('H:i', strtotime($shift['shift_time']));
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр смены №<?= $shift['id'] ?> - АГЗС</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Система учета АГЗС</h1>
            <nav>
                <a href="index.php" class="tab-btn">Закрытие смены</a>
                <a href="reports.php" class="tab-btn">Отчеты</a>
                <a href="monthly.php" class="tab-btn">Продано за месяц</a>
            </nav>
        </header>

        <main>
            <div class="shift-view">
                <div class="section-header">
                    <h2>Смена №<?= $shift['id'] ?></h2>
                    <div class="actions">
                        <a href="reports.php" class="btn btn-secondary">← Назад к отчетам</a>
                        <a href="delete_shift.php?id=<?= $shift['id'] ?>"
                           class="btn btn-danger"
                           onclick="return confirm('Вы уверены, что хотите удалить эту смену?')">
                            Удалить смену
                        </a>
                    </div>
                </div>

                <!-- Основная информация -->
                <section class="basic-info">
                    <h3>Основная информация</h3>
                    <div class="info-grid">
                        <div class="info-item">
                            <label>Дата смены:</label>
                            <span><?= escape($shift['formatted_date']) ?></span>
                        </div>
                        <div class="info-item">
                            <label>Время закрытия:</label>
                            <span><?= escape($shift['formatted_time']) ?></span>
                        </div>
                        <div class="info-item">
                            <label>Дата создания записи:</label>
                            <span><?= date('d.m.Y H:i:s', strtotime($shift['created_at'])) ?></span>
                        </div>
                    </div>
                </section>

                <!-- Подсчет наличных -->
                <section class="money-details">
                    <h3>Подсчет наличных денег</h3>
                    <div class="money-breakdown">
                        <div class="money-row">
                            <span class="denom">1 руб.:</span>
                            <span class="count"><?= $shift['money_1'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_1'] * 1) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">2 руб.:</span>
                            <span class="count"><?= $shift['money_2'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_2'] * 2) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">5 руб.:</span>
                            <span class="count"><?= $shift['money_5'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_5'] * 5) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">10 руб.:</span>
                            <span class="count"><?= $shift['money_10'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_10'] * 10) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">50 руб.:</span>
                            <span class="count"><?= $shift['money_50'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_50'] * 50) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">100 руб.:</span>
                            <span class="count"><?= $shift['money_100'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_100'] * 100) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">200 руб.:</span>
                            <span class="count"><?= $shift['money_200'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_200'] * 200) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">500 руб.:</span>
                            <span class="count"><?= $shift['money_500'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_500'] * 500) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">1000 руб.:</span>
                            <span class="count"><?= $shift['money_1000'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_1000'] * 1000) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">2000 руб.:</span>
                            <span class="count"><?= $shift['money_2000'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_2000'] * 2000) ?> руб.</span>
                        </div>
                        <div class="money-row">
                            <span class="denom">5000 руб.:</span>
                            <span class="count"><?= $shift['money_5000'] ?> шт.</span>
                            <span class="sum"><?= formatNumber($shift['money_5000'] * 5000) ?> руб.</span>
                        </div>
                        <div class="money-row total-money-row">
                            <span class="denom"><strong>Итого подсчитано:</strong></span>
                            <span class="count"></span>
                            <span class="sum"><strong><?= formatNumber($shift['total_cash']) ?> руб.</strong></span>
                        </div>
                    </div>
                </section>

                <!-- Основные показатели -->
                <section class="main-indicators">
                    <h3>Основные показатели</h3>
                    <div class="indicators-grid">
                        <div class="indicator-item">
                            <label>СУГ (Продажа за смену):</label>
                            <span class="value"><?= formatNumber($shift['sug_sale']) ?> руб.</span>
                        </div>
                        <div class="indicator-item">
                            <label>Наличка:</label>
                            <span class="value"><?= formatNumber($shift['cash_amount']) ?> руб.</span>
                        </div>
                        <div class="indicator-item">
                            <label>Процентовщик (начало смены):</label>
                            <span class="value"><?= formatNumber($shift['percentage_start']) ?></span>
                        </div>
                        <div class="indicator-item">
                            <label>Процентовщик (конец смены):</label>
                            <span class="value"><?= formatNumber($shift['percentage_end']) ?></span>
                        </div>
                    </div>
                </section>

                <!-- Расчеты -->
                <section class="calculations-section">
                    <h3>Расчеты</h3>
                    <div class="calculations-grid">
                        <div class="calc-item">
                            <label>Реализация за смену по ТРК:</label>
                            <span class="value"><?= formatNumber($shift['trk_sale']) ?> руб.</span>
                        </div>
                        <div class="calc-item">
                            <label>Расчётный литраж:</label>
                            <span class="value"><?= formatNumber($shift['theoretical_liters']) ?> л.</span>
                        </div>
                        <div class="calc-item">
                            <label>Фактический литраж:</label>
                            <span class="value"><?= formatNumber($shift['actual_liters']) ?> л.</span>
                        </div>
                        <div class="calc-item">
                            <label>Отклонение:</label>
                            <span class="value deviation <?= $shift['deviation'] > 0 ? 'positive' : ($shift['deviation'] < 0 ? 'negative' : '') ?>">
                                <?= formatNumber($shift['deviation']) ?> л.
                                <?php if ($shift['deviation'] > 0): ?>
                                    (Излишек)
                                <?php elseif ($shift['deviation'] < 0): ?>
                                    (Недостача)
                                <?php else: ?>
                                    (Норма)
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                </section>

                <!-- Кнопки действий -->
                <div class="action-buttons">
                    <button onclick="window.print()" class="btn btn-info">Печать</button>
                    <a href="reports.php" class="btn btn-primary">Вернуться к отчетам</a>
                </div>
            </div>
        </main>
    </div>

    <script src="src/script.js"></script>
</body>
</html>
