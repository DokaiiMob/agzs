// Основные функции для работы с формой закрытия смены

// Форматирование числа с разделителями тысяч
function formatNumber(num) {
    return new Intl.NumberFormat('ru-RU', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(num);
}

// Обновление расчетов денег
function updateMoneyCalculations() {
    const denominations = [1, 2, 5, 10, 50, 100, 200, 500, 1000, 2000, 5000];
    let totalCash = 0;

    denominations.forEach(denom => {
        const input = document.getElementById(`money_${denom}`);
        const totalSpan = document.getElementById(`total_${denom}`);

        if (input && totalSpan) {
            const count = parseInt(input.value) || 0;
            const sum = count * denom;
            totalSpan.textContent = formatNumber(sum);
            totalCash += sum;
        }
    });

    const totalCashElement = document.getElementById('total-cash');
    if (totalCashElement) {
        totalCashElement.textContent = formatNumber(totalCash);
    }
}

// Обновление основных расчетов
function updateCalculations() {
    const sugSale = parseFloat(document.getElementById('sug_sale')?.value) || 0;
    const percentageStart = parseFloat(document.getElementById('percentage_start')?.value) || 0;
    const percentageEnd = parseFloat(document.getElementById('percentage_end')?.value) || 0;

    // Обновляем отображаемые значения
    const calcPercentageStartElement = document.getElementById('calc-percentage-start');
    const calcTrkSaleElement = document.getElementById('calc-trk-sale');
    const calcPercentageEndElement = document.getElementById('calc-percentage-end');
    const calcTheoreticalLitersElement = document.getElementById('calc-theoretical-liters');
    const calcActualLitersElement = document.getElementById('calc-actual-liters');
    const calcDeviationElement = document.getElementById('calc-deviation');

    if (calcPercentageStartElement) {
        calcPercentageStartElement.textContent = formatNumber(percentageStart);
    }

    if (calcTrkSaleElement) {
        calcTrkSaleElement.textContent = formatNumber(sugSale);
    }

    if (calcPercentageEndElement) {
        calcPercentageEndElement.textContent = formatNumber(percentageEnd);
    }

    // Расчеты
    const theoreticalLiters = (percentageStart * 200) - (percentageEnd * 200);
    const actualLiters = percentageEnd * 200;
    const deviation = actualLiters - theoreticalLiters;

    if (calcTheoreticalLitersElement) {
        calcTheoreticalLitersElement.textContent = formatNumber(theoreticalLiters);
    }

    if (calcActualLitersElement) {
        calcActualLitersElement.textContent = formatNumber(actualLiters);
    }

    if (calcDeviationElement) {
        calcDeviationElement.textContent = formatNumber(deviation);

        // Обновляем класс для цвета
        calcDeviationElement.className = 'deviation';
        if (deviation > 0) {
            calcDeviationElement.classList.add('positive');
        } else if (deviation < 0) {
            calcDeviationElement.classList.add('negative');
        }
    }
}

// Сброс формы
function resetForm() {
    if (confirm('Вы уверены, что хотите очистить все поля?')) {
        // Сбрасываем все поля
        document.getElementById('shift-form')?.reset();

        // Обновляем расчеты
        updateMoneyCalculations();
        updateCalculations();

        // Устанавливаем текущую дату
        const dateInput = document.getElementById('shift_date');
        if (dateInput) {
            dateInput.value = new Date().toISOString().split('T')[0];
        }
    }
}

// Автообновление времени МСК+4
function updateMoscowPlus4Time() {
    const timeElement = document.querySelector('input[readonly]');
    if (timeElement && timeElement.value.match(/^\d{2}:\d{2}:\d{2}$/)) {
        const now = new Date();
        // Получаем UTC время
        const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
        // Добавляем 7 часов для МСК+4 (МСК это UTC+3, значит МСК+4 = UTC+7)
        const mskPlus4 = new Date(utc + (7 * 3600000));
        timeElement.value = mskPlus4.toTimeString().substr(0, 8);
    }
}

// Валидация формы
function validateForm() {
    const form = document.getElementById('shift-form');
    if (!form) return true;

    let isValid = true;
    const errors = [];

    // Проверяем дату
    const dateInput = document.getElementById('shift_date');
    if (dateInput && !dateInput.value) {
        errors.push('Необходимо указать дату смены');
        isValid = false;
    }

    // Проверяем основные поля
    const sugSale = parseFloat(document.getElementById('sug_sale')?.value) || 0;
    const cashAmount = parseFloat(document.getElementById('cash_amount')?.value) || 0;
    const percentageStart = parseFloat(document.getElementById('percentage_start')?.value) || 0;
    const percentageEnd = parseFloat(document.getElementById('percentage_end')?.value) || 0;

    if (sugSale < 0) {
        errors.push('СУГ не может быть отрицательным');
        isValid = false;
    }

    if (cashAmount < 0) {
        errors.push('Количество наличных не может быть отрицательным');
        isValid = false;
    }

    if (percentageStart < 0 || percentageEnd < 0) {
        errors.push('Процентовщик не может быть отрицательным');
        isValid = false;
    }

    if (!isValid) {
        alert('Ошибки в форме:\n' + errors.join('\n'));
    }

    return isValid;
}

// Функции для месячных отчетов
function validateMonthlyForm() {
    const surname = document.getElementById('employee_surname')?.value.trim();
    const sugEnd = parseFloat(document.getElementById('sug_end_amount')?.value) || 0;

    if (!surname) {
        alert('Необходимо указать фамилию сотрудника');
        return false;
    }

    if (sugEnd <= 0) {
        alert('СУГ на конец смены должен быть больше 0');
        return false;
    }

    return true;
}

// Функции для экспорта и печати
function exportToCSV() {
    const table = document.getElementById('reports-table');
    if (!table) {
        alert('Таблица для экспорта не найдена');
        return;
    }

    let csv = '\uFEFF'; // BOM для корректного отображения в Excel

    // Заголовки
    const headers = [];
    table.querySelectorAll('thead th').forEach(th => {
        if (th.textContent !== 'Действия') {
            headers.push('"' + th.textContent.replace(/"/g, '""') + '"');
        }
    });
    csv += headers.join(';') + '\r\n';

    // Данные
    table.querySelectorAll('tbody tr').forEach(tr => {
        const row = [];
        tr.querySelectorAll('td').forEach((td, index) => {
            if (index < tr.children.length - 1) { // Исключаем последнюю колонку "Действия"
                let cellText = td.textContent.trim();
                // Заменяем точки на запятые для чисел (для Excel)
                if (cellText.match(/^\d+\.\d+/)) {
                    cellText = cellText.replace('.', ',');
                }
                row.push('"' + cellText.replace(/"/g, '""') + '"');
            }
        });
        csv += row.join(';') + '\r\n';
    });

    // Скачивание файла
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'azs_reports_' + new Date().toISOString().split('T')[0] + '.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Функция для автозаполнения полей
function autofillFromPreviousShift() {
    // Эта функция может быть расширена для автозаполнения
    // на основе данных предыдущей смены
    console.log('Автозаполнение пока не реализовано');
}

// Функция для сохранения в localStorage
function saveToLocalStorage() {
    if (!localStorage) return;

    const formData = {};
    const form = document.getElementById('shift-form');
    if (!form) return;

    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        if (input.name && input.type !== 'submit' && input.type !== 'reset') {
            formData[input.name] = input.value;
        }
    });

    localStorage.setItem('azs_form_backup', JSON.stringify(formData));
}

// Функция для восстановления из localStorage
function restoreFromLocalStorage() {
    if (!localStorage) return;

    const savedData = localStorage.getItem('azs_form_backup');
    if (!savedData) return;

    try {
        const formData = JSON.parse(savedData);

        Object.keys(formData).forEach(name => {
            const input = document.querySelector(`[name="${name}"]`);
            if (input && input.type !== 'date') { // Не восстанавливаем дату
                input.value = formData[name];
            }
        });

        // Обновляем расчеты после восстановления
        updateMoneyCalculations();
        updateCalculations();

    } catch (e) {
        console.error('Ошибка при восстановлении данных:', e);
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    // Обновляем время МСК+4 каждую секунду
    updateMoscowPlus4Time();
    setInterval(updateMoscowPlus4Time, 1000);

    // Добавляем обработчики событий для полей денег
    const moneyInputs = document.querySelectorAll('input[data-value]');
    moneyInputs.forEach(input => {
        input.addEventListener('input', updateMoneyCalculations);
        input.addEventListener('change', updateMoneyCalculations);
    });

    // Добавляем обработчики для основных расчетов
    const calcInputs = document.querySelectorAll('#sug_sale, #percentage_start, #percentage_end');
    calcInputs.forEach(input => {
        input.addEventListener('input', updateCalculations);
        input.addEventListener('change', updateCalculations);
    });

    // Обработчик отправки формы
    const shiftForm = document.getElementById('shift-form');
    if (shiftForm) {
        shiftForm.addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }

            // Очищаем сохраненные данные при успешной отправке
            localStorage.removeItem('azs_form_backup');
        });
    }

    // Обработчики для месячных отчетов
    const monthlyForm = document.querySelector('form[action=""][method="POST"]');
    if (monthlyForm && monthlyForm.querySelector('input[name="action"][value="add_record"]')) {
        monthlyForm.addEventListener('submit', function(e) {
            if (!validateMonthlyForm()) {
                e.preventDefault();
                return false;
            }
        });
    }

    // Автосохранение в localStorage каждые 30 секунд
    setInterval(saveToLocalStorage, 30000);

    // Восстанавливаем данные при загрузке (кроме главной страницы с формой)
    if (window.location.pathname.includes('index.php') || window.location.pathname.endsWith('/')) {
        // Предлагаем восстановить данные только если есть сохраненные
        const savedData = localStorage.getItem('azs_form_backup');
        if (savedData) {
            if (confirm('Найдены несохраненные данные. Восстановить их?')) {
                restoreFromLocalStorage();
            } else {
                localStorage.removeItem('azs_form_backup');
            }
        }
    }

    // Первоначальный расчет
    updateMoneyCalculations();
    updateCalculations();

    // Добавляем обработчики для полей с копейками
    const decimalInputs = document.querySelectorAll('input[step="0.01"]');
    decimalInputs.forEach(input => {
        // Форматируем при потере фокуса
        input.addEventListener('blur', function() {
            if (this.value) {
                const value = parseFloat(this.value) || 0;
                this.value = value.toFixed(2);
            }
        });

        // Разрешаем только числа и точку
        input.addEventListener('keypress', function(e) {
            const char = String.fromCharCode(e.which);
            if (!/[\d\.]/.test(char) && e.which !== 8 && e.which !== 0) {
                e.preventDefault();
            }

            // Запрещаем более одной точки
            if (char === '.' && this.value.includes('.')) {
                e.preventDefault();
            }
        });
    });

    // Обработчик для клавиши Enter в полях формы
    const formInputs = document.querySelectorAll('input');
    formInputs.forEach((input, index) => {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();

                // Переходим к следующему полю
                const nextInput = formInputs[index + 1];
                if (nextInput) {
                    nextInput.focus();
                } else {
                    // Если это последнее поле, фокусируемся на кнопке отправки
                    const submitBtn = document.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        submitBtn.focus();
                    }
                }
            }
        });
    });
});

// Функция для подтверждения перед уходом со страницы
window.addEventListener('beforeunload', function(e) {
    const form = document.getElementById('shift-form');
    if (!form) return;

    // Проверяем, есть ли несохраненные данные
    let hasUnsavedData = false;
    const inputs = form.querySelectorAll('input[type="number"]');
    inputs.forEach(input => {
        if (input.value && parseFloat(input.value) > 0) {
            hasUnsavedData = true;
        }
    });

    if (hasUnsavedData) {
        saveToLocalStorage();
        const message = 'У вас есть несохраненные данные. Вы уверены, что хотите покинуть страницу?';
        e.returnValue = message;
        return message;
    }
});

// Дополнительные утилиты
const AZS_Utils = {
    // Функция для получения статистики по отклонениям
    getDeviationStats: function(deviations) {
        const positive = deviations.filter(d => d > 0);
        const negative = deviations.filter(d => d < 0);
        const zero = deviations.filter(d => d === 0);

        return {
            total: deviations.length,
            positive: positive.length,
            negative: negative.length,
            zero: zero.length,
            averagePositive: positive.length ? positive.reduce((a, b) => a + b, 0) / positive.length : 0,
            averageNegative: negative.length ? negative.reduce((a, b) => a + b, 0) / negative.length : 0
        };
    },

    // Функция для валидации времени МСК+4
    isValidMskPlus4Time: function(timeString) {
        const timeRegex = /^([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$/;
        return timeRegex.test(timeString);
    },

    // Функция для конвертации рублей в копейки и обратно
    rublesToKopecks: function(rubles) {
        return Math.round(rubles * 100);
    },

    kopecksToRubles: function(kopecks) {
        return kopecks / 100;
    }
};

// Экспортируем утилиты в глобальную область видимости
window.AZS_Utils = AZS_Utils;
