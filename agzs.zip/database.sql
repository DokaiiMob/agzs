-- Создание базы данных для системы учета АГЗС
CREATE DATABASE IF NOT EXISTS azs_system
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE azs_system;

-- Таблица для хранения данных закрытия смены
CREATE TABLE IF NOT EXISTS shift_closures (
    id INT AUTO_INCREMENT PRIMARY KEY,
    shift_date DATE NOT NULL,
    shift_time TIME NOT NULL,

    -- Подсчет наличных денег по номиналам
    money_1 INT DEFAULT 0 COMMENT 'Количество монет 1 руб',
    money_2 INT DEFAULT 0 COMMENT 'Количество монет 2 руб',
    money_5 INT DEFAULT 0 COMMENT 'Количество монет 5 руб',
    money_10 INT DEFAULT 0 COMMENT 'Количество монет 10 руб',
    money_50 INT DEFAULT 0 COMMENT 'Количество купюр 50 руб',
    money_100 INT DEFAULT 0 COMMENT 'Количество купюр 100 руб',
    money_200 INT DEFAULT 0 COMMENT 'Количество купюр 200 руб',
    money_500 INT DEFAULT 0 COMMENT 'Количество купюр 500 руб',
    money_1000 INT DEFAULT 0 COMMENT 'Количество купюр 1000 руб',
    money_2000 INT DEFAULT 0 COMMENT 'Количество купюр 2000 руб',
    money_5000 INT DEFAULT 0 COMMENT 'Количество купюр 5000 руб',

    -- Общая сумма наличных
    total_cash DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Общая сумма наличных',

    -- Основные показатели (с поддержкой копеек)
    sug_sale DECIMAL(12,2) DEFAULT 0.00 COMMENT 'СУГ (Продажа за смену)',
    cash_amount DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Сколько денег (Наличка)',
    percentage_start DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Процентовщик на начало смены',
    percentage_end DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Процентовщик на конец смены',

    -- Расчетные поля
    trk_sale DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Реализация за смену по ТРК',
    theoretical_liters DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Расчётный литраж',
    actual_liters DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Фактический литраж',
    deviation DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Отклонение',

    -- Метаданные
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_shift_date (shift_date),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Новая таблица для месячных отчетов
CREATE TABLE IF NOT EXISTS monthly_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_surname VARCHAR(100) NOT NULL COMMENT 'Фамилия сотрудника',
    sug_end_amount DECIMAL(12,2) NOT NULL COMMENT 'СУГ на конец смены',
    previous_sug_amount DECIMAL(12,2) DEFAULT 0.00 COMMENT 'Предыдущий СУГ',
    total_difference DECIMAL(12,2) GENERATED ALWAYS AS (sug_end_amount - previous_sug_amount) STORED COMMENT 'Разница между текущим и предыдущим СУГ',
    report_month INT NOT NULL COMMENT 'Месяц отчета',
    report_year INT NOT NULL COMMENT 'Год отчета',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_employee_month (employee_surname, report_month, report_year),
    INDEX idx_report_date (report_year, report_month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Таблица для хранения настроек системы
CREATE TABLE IF NOT EXISTS system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value VARCHAR(500) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Вставка базовых настроек
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('percentage_multiplier', '200', 'Множитель для перевода процентовщика в литры'),
('company_name', 'АГЗС Система учета', 'Название компании'),
('currency', 'RUB', 'Валюта системы'),
('timezone_offset', '+4', 'Смещение времени от МСК в часах')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Создание представления для отчетов
CREATE VIEW shift_reports AS
SELECT
    id,
    shift_date,
    shift_time,
    DATE_FORMAT(shift_date, '%d.%m.%Y') as formatted_date,
    TIME_FORMAT(shift_time, '%H:%i') as formatted_time,
    total_cash,
    sug_sale,
    cash_amount,
    percentage_start,
    percentage_end,
    trk_sale,
    theoretical_liters,
    actual_liters,
    deviation,
    CASE
        WHEN deviation > 0 THEN 'Излишек'
        WHEN deviation < 0 THEN 'Недостача'
        ELSE 'Норма'
    END as deviation_status,
    created_at
FROM shift_closures
ORDER BY shift_date DESC, shift_time DESC;

-- Создание представления для месячных отчетов
CREATE VIEW monthly_reports_view AS
SELECT
    mr.id,
    mr.employee_surname,
    mr.sug_end_amount,
    mr.previous_sug_amount,
    mr.total_difference,
    mr.report_month,
    mr.report_year,
    MONTHNAME(STR_TO_DATE(mr.report_month, '%m')) as month_name,
    DATE_FORMAT(mr.created_at, '%d.%m.%Y %H:%i') as formatted_created_at,
    mr.created_at
FROM monthly_reports mr
ORDER BY mr.report_year DESC, mr.report_month DESC, mr.employee_surname ASC;
