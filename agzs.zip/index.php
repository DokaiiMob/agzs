<?php
require_once 'config.php';

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Получение данных из формы
        $shift_date = $_POST['shift_date'] ?? date('Y-m-d');
        $shift_time = getCurrentMskPlus4Time(); // Автоматическое время МСК+4

        // Подсчет наличных денег
        $money_denominations = [1, 2, 5, 10, 50, 100, 200, 500, 1000, 2000, 5000];
        $total_cash = 0;
        $money_data = [];

        foreach ($money_denominations as $denom) {
            $count = (int)($_POST["money_$denom"] ?? 0);
            $money_data["money_$denom"] = $count;
            $total_cash += $denom * $count;
        }

        // Основные показатели (с поддержкой копеек)
        $sug_sale = round((float)($_POST['sug_sale'] ?? 0), 2);
        $cash_amount = round((float)($_POST['cash_amount'] ?? 0), 2);
        $percentage_start = round((float)($_POST['percentage_start'] ?? 0), 2);
        $percentage_end = round((float)($_POST['percentage_end'] ?? 0), 2);

        // Расчеты
        $trk_sale = $sug_sale; // Реализация за смену по ТРК = СУГ
        $theoretical_liters = ($percentage_start * 200) - ($percentage_end * 200); // Расчётный литраж
        $actual_liters = $percentage_end * 200; // Фактический литраж
        $deviation = $actual_liters - $theoretical_liters; // Отклонение

        // Подготовка SQL запроса
        $sql = "INSERT INTO shift_closures (
            shift_date, shift_time,
            money_1, money_2, money_5, money_10, money_50, money_100,
            money_200, money_500, money_1000, money_2000, money_5000,
            total_cash, sug_sale, cash_amount, percentage_start, percentage_end,
            trk_sale, theoretical_liters, actual_liters, deviation
        ) VALUES (
            :shift_date, :shift_time,
            :money_1, :money_2, :money_5, :money_10, :money_50, :money_100,
            :money_200, :money_500, :money_1000, :money_2000, :money_5000,
            :total_cash, :sug_sale, :cash_amount, :percentage_start, :percentage_end,
            :trk_sale, :theoretical_liters, :actual_liters, :deviation
        )";

        $stmt = $pdo->prepare($sql);

        // Выполнение запроса
        $params = array_merge([
            'shift_date' => $shift_date,
            'shift_time' => $shift_time,
            'total_cash' => $total_cash,
            'sug_sale' => $sug_sale,
            'cash_amount' => $cash_amount,
            'percentage_start' => $percentage_start,
            'percentage_end' => $percentage_end,
            'trk_sale' => $trk_sale,
            'theoretical_liters' => $theoretical_liters,
            'actual_liters' => $actual_liters,
            'deviation' => $deviation
        ], $money_data);

        $stmt->execute($params);

        $success_message = "Смена успешно закрыта! ID записи: " . $pdo->lastInsertId();

    } catch (Exception $e) {
        $error_message = "Ошибка при сохранении: " . $e->getMessage();
    }
}

// Получаем текущее время МСК+4 для отображения
$current_msk_plus4_time = getCurrentMskPlus4Time();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Закрытие смены - АГЗС</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Система учета АГЗС</h1>
            <nav>
                <a href="index.php" class="tab-btn active">Закрытие смены</a>
                <a href="reports.php" class="tab-btn">Отчеты</a>
                <a href="monthly.php" class="tab-btn">Продано за месяц</a>
            </nav>
        </header>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?= escape($success_message) ?></div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-error"><?= escape($error_message) ?></div>
        <?php endif; ?>

        <main>
            <form method="POST" action="" id="shift-form">
                <div class="form-header">
                    <h2>Закрытие смены</h2>
                    <div class="date-time-fields">
                        <div class="field-item">
                            <label for="shift_date">Дата смены:</label>
                            <input type="date" id="shift_date" name="shift_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="field-item">
                            <label>Время:</label>
                            <input type="text" value="<?= $current_msk_plus4_time ?>" readonly class="readonly-field">
                            <small>Время устанавливается автоматически при сохранении</small>
                        </div>
                    </div>
                </div>

                <!-- Подсчет наличных денег -->
                <section class="money-count">
                    <h3>Подсчет наличных денег</h3>
                    <div class="money-grid">
                        <?php
                        $denominations = [
                            1 => '1 руб.',
                            2 => '2 руб.',
                            5 => '5 руб.',
                            10 => '10 руб.',
                            50 => '50 руб.',
                            100 => '100 руб.',
                            200 => '200 руб.',
                            500 => '500 руб.',
                            1000 => '1000 руб.',
                            2000 => '2000 руб.',
                            5000 => '5000 руб.'
                        ];

                        foreach ($denominations as $value => $label): ?>
                        <div class="money-item">
                            <label><?= $label ?> x</label>
                            <input type="number"
                                   name="money_<?= $value ?>"
                                   id="money_<?= $value ?>"
                                   min="0"
                                   value="0"
                                   data-value="<?= $value ?>"
                                   onkeyup="updateMoneyCalculations()">
                            <span>=</span>
                            <span class="money-total" id="total_<?= $value ?>">0</span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="total-money">
                        <strong>Общая сумма: <span id="total-cash">0</span> руб.</strong>
                    </div>
                </section>

                <!-- Основные поля -->
                <section class="main-fields">
                    <h3>Основные показатели</h3>
                    <div class="fields-grid">
                        <div class="field-item">
                            <label for="sug_sale">СУГ (Продажа за смену):</label>
                            <input type="number"
                                   id="sug_sale"
                                   name="sug_sale"
                                   step="0.01"
                                   min="0"
                                   value="0.00"
                                   placeholder="0.00"
                                   onkeyup="updateCalculations()">
                            <small>C точностью до копеек</small>
                        </div>
                        <div class="field-item">
                            <label for="cash_amount">Сколько денег (Наличка):</label>
                            <input type="number"
                                   id="cash_amount"
                                   name="cash_amount"
                                   step="0.01"
                                   min="0"
                                   value="0.00"
                                   placeholder="0.00">
                            <small>C точностью до копеек</small>
                        </div>
                        <div class="field-item">
                            <label for="percentage_start">Процентовщик (начало смены):</label>
                            <input type="number"
                                   id="percentage_start"
                                   name="percentage_start"
                                   step="0.01"
                                   min="0"
                                   value="0.00"
                                   placeholder="0.00"
                                   onkeyup="updateCalculations()">
                            <small>C точностью до копеек</small>
                        </div>
                        <div class="field-item">
                            <label for="percentage_end">Процентовщик на конец смены:</label>
                            <input type="number"
                                   id="percentage_end"
                                   name="percentage_end"
                                   step="0.01"
                                   min="0"
                                   value="0.00"
                                   placeholder="0.00"
                                   onkeyup="updateCalculations()">
                            <small>C точностью до копеек</small>
                        </div>
                    </div>
                </section>

                <!-- Расчеты -->
                <section class="calculations">
                    <h3>Расчеты закрытия смены</h3>
                    <div class="calc-grid">
                        <div class="calc-item">
                            <label>Процентовщик (начало смены):</label>
                            <span id="calc-percentage-start">0.00</span>
                        </div>
                        <div class="calc-item">
                            <label>Реализация за смену по ТРК:</label>
                            <span id="calc-trk-sale">0.00</span>
                        </div>
                        <div class="calc-item">
                            <label>Процентовщик на конец смены:</label>
                            <span id="calc-percentage-end">0.00</span>
                        </div>
                        <div class="calc-item">
                            <label>Расчётный литраж:</label>
                            <span id="calc-theoretical-liters">0.00</span>
                        </div>
                        <div class="calc-item">
                            <label>Фактический литраж:</label>
                            <span id="calc-actual-liters">0.00</span>
                        </div>
                        <div class="calc-item">
                            <label>Отклонение:</label>
                            <span id="calc-deviation" class="deviation">0.00</span>
                        </div>
                    </div>
                </section>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Закрыть смену</button>
                    <button type="reset" class="btn btn-secondary" onclick="resetForm()">Очистить</button>
                </div>
            </form>
        </main>
    </div>

    <script src="src/script.js"></script>
</body>
</html>
