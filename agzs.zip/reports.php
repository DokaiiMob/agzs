<?php
require_once 'config.php';

// Параметры фильтрации
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$limit = (int)($_GET['limit'] ?? 50);

// Построение SQL запроса
$sql = "SELECT * FROM shift_reports WHERE 1=1";
$params = [];

if ($date_from) {
    $sql .= " AND shift_date >= :date_from";
    $params['date_from'] = $date_from;
}

if ($date_to) {
    $sql .= " AND shift_date <= :date_to";
    $params['date_to'] = $date_to;
}

$sql .= " ORDER BY shift_date DESC, shift_time DESC LIMIT :limit";
$params['limit'] = $limit;

$stmt = $pdo->prepare($sql);

// Привязка параметров
foreach ($params as $key => $value) {
    if ($key === 'limit') {
        $stmt->bindValue($key, $value, PDO::PARAM_INT);
    } else {
        $stmt->bindValue($key, $value);
    }
}

$stmt->execute();
$reports = $stmt->fetchAll();

// Статистика
$stats_sql = "SELECT
    COUNT(*) as total_shifts,
    SUM(sug_sale) as total_sug_sale,
    SUM(cash_amount) as total_cash_amount,
    SUM(total_cash) as total_cash_counted,
    AVG(deviation) as avg_deviation
FROM shift_closures";

$stats_params = [];
if ($date_from || $date_to) {
    $stats_sql .= " WHERE 1=1";
    if ($date_from) {
        $stats_sql .= " AND shift_date >= :date_from";
        $stats_params['date_from'] = $date_from;
    }
    if ($date_to) {
        $stats_sql .= " AND shift_date <= :date_to";
        $stats_params['date_to'] = $date_to;
    }
}

$stats_stmt = $pdo->prepare($stats_sql);
$stats_stmt->execute($stats_params);
$statistics = $stats_stmt->fetch();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Отчеты - АГЗС</title>
    <link rel="stylesheet" href="src/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Система учета АГЗС</h1>
            <nav>
                <a href="index.php" class="tab-btn">Закрытие смены</a>
                <a href="reports.php" class="tab-btn active">Отчеты</a>
                <a href="monthly.php" class="tab-btn">Продано за месяц</a>
            </nav>
        </header>

        <main>
            <!-- Фильтры -->
            <section class="filters">
                <h2>Фильтры</h2>
                <form method="GET" action="" class="filter-form">
                    <div class="filter-row">
                        <div class="filter-item">
                            <label for="date_from">Дата с:</label>
                            <input type="date" id="date_from" name="date_from" value="<?= escape($date_from) ?>">
                        </div>
                        <div class="filter-item">
                            <label for="date_to">Дата по:</label>
                            <input type="date" id="date_to" name="date_to" value="<?= escape($date_to) ?>">
                        </div>
                        <div class="filter-item">
                            <label for="limit">Количество записей:</label>
                            <select id="limit" name="limit">
                                <option value="25" <?= $limit == 25 ? 'selected' : '' ?>>25</option>
                                <option value="50" <?= $limit == 50 ? 'selected' : '' ?>>50</option>
                                <option value="100" <?= $limit == 100 ? 'selected' : '' ?>>100</option>
                                <option value="200" <?= $limit == 200 ? 'selected' : '' ?>>200</option>
                            </select>
                        </div>
                        <div class="filter-actions">
                            <button type="submit" class="btn btn-primary">Применить</button>
                            <a href="reports.php" class="btn btn-secondary">Сбросить</a>
                        </div>
                    </div>
                </form>
            </section>

            <!-- Статистика -->
            <?php if ($statistics): ?>
            <section class="statistics">
                <h2>Статистика</h2>
                <div class="stats-grid">
                    <div class="stat-item">
                        <div class="stat-label">Всего смен:</div>
                        <div class="stat-value"><?= $statistics['total_shifts'] ?></div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Общая продажа СУГ:</div>
                        <div class="stat-value"><?= formatNumber($statistics['total_sug_sale']) ?> руб.</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Общая наличка:</div>
                        <div class="stat-value"><?= formatNumber($statistics['total_cash_amount']) ?> руб.</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Подсчитано наличных:</div>
                        <div class="stat-value"><?= formatNumber($statistics['total_cash_counted']) ?> руб.</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-label">Среднее отклонение:</div>
                        <div class="stat-value <?= $statistics['avg_deviation'] > 0 ? 'positive' : ($statistics['avg_deviation'] < 0 ? 'negative' : '') ?>">
                            <?= formatNumber($statistics['avg_deviation']) ?> л.
                        </div>
                    </div>
                </div>
            </section>
            <?php endif; ?>

            <!-- Таблица отчетов -->
            <section class="reports-table-section">
                <div class="section-header">
                    <h2>Отчеты по сменам</h2>
                    <div class="export-actions">
                        <button onclick="exportToCSV()" class="btn btn-success">Экспорт CSV</button>
                        <button onclick="printReports()" class="btn btn-info">Печать</button>
                    </div>
                </div>

                <?php if (empty($reports)): ?>
                    <div class="no-data">
                        <p>Нет данных для отображения</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="reports-table" id="reports-table">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Время</th>
                                    <th>СУГ продажа</th>
                                    <th>Наличка</th>
                                    <th>Подсчитано</th>
                                    <th>% начало</th>
                                    <th>% конец</th>
                                    <th>Расчёт. литраж</th>
                                    <th>Факт. литраж</th>
                                    <th>Отклонение</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $report): ?>
                                    <tr>
                                        <td><?= escape($report['formatted_date']) ?></td>
                                        <td><?= escape($report['formatted_time']) ?></td>
                                        <td><?= formatNumber($report['sug_sale']) ?> руб.</td>
                                        <td><?= formatNumber($report['cash_amount']) ?> руб.</td>
                                        <td><?= formatNumber($report['total_cash']) ?> руб.</td>
                                        <td><?= formatNumber($report['percentage_start']) ?></td>
                                        <td><?= formatNumber($report['percentage_end']) ?></td>
                                        <td><?= formatNumber($report['theoretical_liters']) ?> л.</td>
                                        <td><?= formatNumber($report['actual_liters']) ?> л.</td>
                                        <td class="<?= $report['deviation'] > 0 ? 'positive' : ($report['deviation'] < 0 ? 'negative' : '') ?>">
                                            <?= formatNumber($report['deviation']) ?> л.
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?= strtolower($report['deviation_status']) ?>">
                                                <?= escape($report['deviation_status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="view_shift.php?id=<?= $report['id'] ?>" class="btn btn-small btn-info">
                                                Просмотр
                                            </a>
                                            <a href="delete_shift.php?id=<?= $report['id'] ?>"
                                               class="btn btn-small btn-danger"
                                               onclick="return confirm('Вы уверены, что хотите удалить эту запись?')">
                                                Удалить
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <script src="src/script.js"></script>
    <script>
        function exportToCSV() {
            const table = document.getElementById('reports-table');
            let csv = '';

            // Заголовки
            const headers = [];
            table.querySelectorAll('thead th').forEach(th => {
                if (th.textContent !== 'Действия') {
                    headers.push('"' + th.textContent.replace(/"/g, '""') + '"');
                }
            });
            csv += headers.join(',') + '\n';

            // Данные
            table.querySelectorAll('tbody tr').forEach(tr => {
                const row = [];
                tr.querySelectorAll('td').forEach((td, index) => {
                    if (index < tr.children.length - 1) { // Исключаем последнюю колонку "Действия"
                        row.push('"' + td.textContent.trim().replace(/"/g, '""') + '"');
                    }
                });
                csv += row.join(',') + '\n';
            });

            // Скачивание файла
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'reports_' + new Date().toISOString().split('T')[0] + '.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function printReports() {
            window.print();
        }
    </script>
</body>
</html>
