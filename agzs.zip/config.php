<?php
// Конфигурация базы данных MariaDB
$db_host = 'localhost';
$db_name = 'azs_system';
$db_user = 'root';
$db_pass = '';

try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция для экранирования данных
function escape($data) {
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// Функция для форматирования числа с копейками
function formatNumber($number, $decimals = 2) {
    // Проверяем на null и приводим к числу
    if ($number === null || $number === '') {
        $number = 0;
    }
    return number_format((float)$number, $decimals, '.', ' ');
}

// Функция для получения времени МСК+4 (Самарское время)
function getMoscowPlus4Time() {
    $moscow_time = new DateTime('now', new DateTimeZone('Europe/Moscow'));
    $moscow_time->add(new DateInterval('PT4H')); // Добавляем 4 часа
    return $moscow_time;
}

// Функция для форматирования времени МСК+4
function getCurrentMskPlus4Time() {
    return getMoscowPlus4Time()->format('H:i:s');
}
?>
